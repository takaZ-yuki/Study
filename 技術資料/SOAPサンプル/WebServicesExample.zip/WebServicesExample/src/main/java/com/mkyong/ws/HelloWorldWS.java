package com.mkyong.ws;

import javax.jws.WebService;

import org.springframework.stereotype.Component;

@Component
@WebService
public class HelloWorldWS {

	public String test() {

		return "hoge";

	}

}